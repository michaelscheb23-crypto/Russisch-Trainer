plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "de.russischtrainer"; compileSdk = 35
 defaultConfig { applicationId = "de.russischtrainer"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1" } }
kotlin { jvmToolchain(17) }
