package de.russischtrainer

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val demo = listOf("дом" to "Haus", "вода" to "Wasser", "книга" to "Buch", "сегодня" to "heute")
    private var tts: TextToSpeech? = null
    private lateinit var prompt: TextView
    private lateinit var status: TextView
    private var current = 0
    private var reverse = false
    private var attempts = 0
    private val prefs by lazy { getSharedPreferences("progress", MODE_PRIVATE) }
    private val speechRequest = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = prefs.getInt("current", 0).coerceIn(demo.indices)
        reverse = prefs.getBoolean("reverse", false)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 32, 24, 24) }
        prompt = TextView(this).apply { textSize = 32f }
        status = TextView(this).apply { textSize = 17f }
        layout.addView(prompt)
        layout.addView(status)
        fun button(label: String, action: () -> Unit) { layout.addView(Button(this).apply { text = label; setOnClickListener { action() } }) }
        button("Wort vorlesen") { speakQuestion() }
        button("Antwort sprechen") { listen() }
        button("Lösung anzeigen") { status.text = "Lösung: ${answer()}" }
        button("Richtig / Nächstes Wort") { next() }
        button("Falsch / Noch ein Versuch") { attempts++; if (attempts >= 2) { status.text = "Lösung: ${answer()}"; prefs.edit().putInt("errors_$current", prefs.getInt("errors_$current", 0)+1).apply() } else status.text = "Versuche es noch einmal." }
        button("Richtung wechseln") { reverse = !reverse; save(); showWord() }
        setContentView(layout)
        showWord()
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 22)
    }
    private fun question() = if (reverse) demo[current].second else demo[current].first
    private fun answer() = if (reverse) demo[current].first else demo[current].second
    private fun save() { prefs.edit().putInt("current", current).putBoolean("reverse", reverse).apply() }
    private fun showWord() { prompt.text = question(); status.text = if (reverse) "Deutsch → Russisch" else "Russisch → Deutsch"; speakQuestion() }
    private fun next() { attempts = 0; val others = demo.indices.filter { it != current }; current = others.random(); reverse = !reverse; save(); showWord() }
    private fun speakQuestion() { tts?.language = if (reverse) Locale.GERMAN else Locale("ru", "RU"); tts?.speak(question(), TextToSpeech.QUEUE_FLUSH, null, "question") }
    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (reverse) "ru-RU" else "de-DE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        }
        try { startActivityForResult(intent, speechRequest) } catch (e: Exception) { status.text = "Keine Spracherkennung verfügbar: ${e.message}" }
    }
    @Deprecated("Legacy Android speech result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != speechRequest || resultCode != RESULT_OK) return
        val heard = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        val norm = { s: String -> s.lowercase(Locale.ROOT).trim().replace(Regex("[.!?,]"), "") }
        if (norm(heard) == norm(answer())) {
            status.text = "Richtig: $heard"
            prompt.postDelayed({ next() }, 2000)
        } else {
            attempts++
            status.text = if (attempts == 1) "Erkannt: $heard – bitte noch einmal." else "Erkannt: $heard – Lösung: ${answer()}"
            if (attempts >= 2) prefs.edit().putInt("errors_$current", prefs.getInt("errors_$current", 0)+1).apply()
        }
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) speakQuestion() }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}
